Computer Graphics I - Final Project

To read the information about project, please go through report/report.txt file.

To run this project, please open finalProject.html file in any browser.

You can see the object in 3D plane.

By selecting the object with help of cursor, you can rotate the object in all directions and also zoom in and out.

I have provided additional projections of object in projections.html page.